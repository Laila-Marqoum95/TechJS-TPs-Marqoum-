const inquirer = require("inquirer").createPromptModule(); // <- important

// Pokémon prédéfinis
const testPokemons = {
  pikachu: {
    name: "pikachu",
    moves: [
      { name: "thunder-shock", power: 40, accuracy: 100 },
      { name: "quick-attack", power: 30, accuracy: 100 },
      { name: "electro-ball", power: 50, accuracy: 90 },
      { name: "iron-tail", power: 100, accuracy: 75 },
      { name: "volt-tackle", power: 120, accuracy: 70 }
    ]
  },
  charmander: {
    name: "charmander",
    moves: [
      { name: "scratch", power: 40, accuracy: 100 },
      { name: "ember", power: 40, accuracy: 100 },
      { name: "flamethrower", power: 90, accuracy: 100 },
      { name: "smokescreen", power: 0, accuracy: 100 },
      { name: "dragon-rage", power: 60, accuracy: 100 }
    ]
  },
  bulbasaur: {
    name: "bulbasaur",
    moves: [
      { name: "tackle", power: 40, accuracy: 100 },
      { name: "vine-whip", power: 45, accuracy: 100 },
      { name: "razor-leaf", power: 55, accuracy: 95 },
      { name: "sleep-powder", power: 0, accuracy: 75 },
      { name: "solar-beam", power: 120, accuracy: 100 }
    ]
  },
  squirtle: {
    name: "squirtle",
    moves: [
      { name: "tackle", power: 40, accuracy: 100 },
      { name: "water-gun", power: 40, accuracy: 100 },
      { name: "bubble", power: 30, accuracy: 100 },
      { name: "bite", power: 60, accuracy: 100 },
      { name: "hydro-pump", power: 110, accuracy: 80 }
    ]
  }
};

let player = { name: "", hp: 300, moves: [] };
let bot = { name: "", hp: 300, moves: [] };

// Pokémon aléatoire pour le bot
function getRandomPokemon() {
  const keys = Object.keys(testPokemons);
  const randomKey = keys[Math.floor(Math.random() * keys.length)];
  return testPokemons[randomKey];
}

// Choix du joueur
async function choosePokemon() {
  const { pokemonName } = await inquirer({
    type: "list",
    name: "pokemonName",
    message: "Choisissez votre Pokémon :",
    choices: Object.keys(testPokemons)
  });
  return testPokemons[pokemonName];
}

// Tour du joueur
async function playerTurn() {
  console.log(`\nVotre HP: ${player.hp} | Bot HP: ${bot.hp}`);
  const { moveIndex } = await inquirer({
    type: "list",
    name: "moveIndex",
    message: `Quel coup pour ${player.name} ?`,
    choices: player.moves.map((move, i) => ({
      name: `${move.name} (P:${move.power}, A:${move.accuracy})`,
      value: i
    }))
  });

  const move = player.moves[moveIndex];
  if (Math.random() * 100 < move.accuracy) {
    bot.hp -= move.power;
    if (bot.hp < 0) bot.hp = 0;
    console.log(`${player.name} utilise ${move.name} et inflige ${move.power} dégâts !`);
  } else {
    console.log(`${player.name} rate son attaque !`);
  }

  if (bot.hp <= 0) {
    console.log("Vous gagnez !");
    process.exit();
  } else {
    await botTurn();
  }
}

// Tour du bot
async function botTurn() {
  const move = bot.moves[Math.floor(Math.random() * bot.moves.length)];
  if (Math.random() * 100 < move.accuracy) {
    player.hp -= move.power;
    if (player.hp < 0) player.hp = 0;
    console.log(`${bot.name} utilise ${move.name} et inflige ${move.power} dégâts !`);
  } else {
    console.log(`${bot.name} rate son attaque !`);
  }

  if (player.hp <= 0) {
    console.log(" Le bot gagne !");
    process.exit();
  } else {
    await playerTurn();
  }
}

// Démarrage du jeu
async function startGame() {
  console.log("Bienvenue dans le combat Pokémon !");
  player = await choosePokemon();
  player.hp = 300;

  bot = getRandomPokemon();
  bot.hp = 300;
  console.log(`Le bot choisit ${bot.name} !`);

  await playerTurn();
}

startGame();

