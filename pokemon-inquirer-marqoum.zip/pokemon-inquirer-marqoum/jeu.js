
// Pokémon prédéfinis pour jouer directement sans fetch
const testPokemons = {
  pikachu: {
    name: "pikachu",
    moves: [
      {name:"thunder-shock", power:40, accuracy:100},
      {name:"quick-attack", power:30, accuracy:100},
      {name:"electro-ball", power:50, accuracy:90},
      {name:"iron-tail", power:100, accuracy:75},
      {name:"volt-tackle", power:120, accuracy:70}
    ]
  },
  charmander: {
    name:"charmander",
    moves: [
      {name:"scratch", power:40, accuracy:100},
      {name:"ember", power:40, accuracy:100},
      {name:"flamethrower", power:90, accuracy:100},
      {name:"smokescreen", power:0, accuracy:100},
      {name:"dragon-rage", power:60, accuracy:100}
    ]
  },
  bulbasaur: {
    name:"bulbasaur",
    moves: [
      {name:"tackle", power:40, accuracy:100},
      {name:"vine-whip", power:45, accuracy:100},
      {name:"razor-leaf", power:55, accuracy:95},
      {name:"sleep-powder", power:0, accuracy:75},
      {name:"solar-beam", power:120, accuracy:100}
    ]
  },
  squirtle: {
    name:"squirtle",
    moves: [
      {name:"tackle", power:40, accuracy:100},
      {name:"water-gun", power:40, accuracy:100},
      {name:"bubble", power:30, accuracy:100},
      {name:"bite", power:60, accuracy:100},
      {name:"hydro-pump", power:110, accuracy:80}
    ]
  }
};

let player = { name: "", hp: 300, moves: [] };
let bot = { name: "", hp: 300, moves: [] };

async function fetchPokemon(name) {
  name = name.toLowerCase();
  if (testPokemons[name]) return testPokemons[name];
  alert("Pokémon non trouvé !");
  throw new Error("Pokémon non trouvé !");
}

function getRandomPokemon() {
  const keys = Object.keys(testPokemons);
  const randomKey = keys[Math.floor(Math.random() * keys.length)];
  return testPokemons[randomKey];
}

function startGame() {
  const playerName = document.getElementById("playerPokemonInput").value;
  if (!playerName) return alert("Entre un nom de Pokémon");

  fetchPokemon(playerName).then(playerData => {
    player.name = playerData.name; player.hp = 300;
    player.moves = playerData.moves;

    // Pokémon du bot
    const botData = getRandomPokemon();
    bot.name = botData.name; bot.hp = 300;
    bot.moves = botData.moves;

    document.getElementById("playerName").innerText = player.name;
    document.getElementById("botName").innerText = bot.name;
    document.getElementById("battleArea").style.display = "block";
    displayMoves();
    updateHPBars();
    logMessage("Le combat commence !");
  });
}

function displayMoves() {
  const movesDiv = document.getElementById("playerMoves");
  movesDiv.innerHTML = "";
  player.moves.forEach((move, i) => {
    const btn = document.createElement("button");
    btn.innerText = `${move.name} (P:${move.power}, A:${move.accuracy})`;
    btn.onclick = () => playerAttack(i);
    movesDiv.appendChild(btn);
  });
}

function playerAttack(moveIndex) {
  const move = player.moves[moveIndex];
  if (Math.random() * 100 < move.accuracy) {
    bot.hp -= move.power; if (bot.hp < 0) bot.hp = 0;
    logMessage(`${player.name} utilise ${move.name} et inflige ${move.power} dégâts !`);
  } else { logMessage(`${player.name} rate son attaque !`); }
  updateHPBars();
  if (bot.hp <= 0) return logMessage("Vous gagnez !");
  setTimeout(botTurn, 500);
}


function botTurn() {
  const move = bot.moves[Math.floor(Math.random() * bot.moves.length)];
  if (Math.random() * 100 < move.accuracy) {
    player.hp -= move.power; if (player.hp < 0) player.hp = 0;
    logMessage(`${bot.name} utilise ${move.name} et inflige ${move.power} dégâts !`);
  } else { logMessage(`${bot.name} rate son attaque !`); }
  updateHPBars();
  if (player.hp <= 0) logMessage("Le bot gagne !");
}

function updateHPBars() {
  document.getElementById("playerHP").innerText = player.hp;
  document.getElementById("botHP").innerText = bot.hp;
  document.getElementById("playerHPBar").style.width = (player.hp/300*100) + "%";
  document.getElementById("botHPBar").style.width = (bot.hp/300*100) + "%";
}

function logMessage(message) {
  const logDiv = document.getElementById("log");
  logDiv.innerHTML += `<p>${message}</p>`;
  logDiv.scrollTop = logDiv.scrollHeight;
}


