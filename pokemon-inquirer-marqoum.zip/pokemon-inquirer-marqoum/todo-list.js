const todoList = [{
  name: 'review course',
  dueDate: '2025-09-29'
}];

renderTodoList();

function renderTodoList() {
  let todoListHTML = '';

  todoList.forEach((todoObject, index) => {
    const { name, dueDate } = todoObject;
    const html = `
      <div class="todo-item">
        <div>${name}</div>
        <div>${dueDate}</div>
        <button class="delete-todo-button js-delete-todo-button" data-index="${index}">
          Delete
        </button>
      </div>
    `;
    todoListHTML += html;
  });

  document.querySelector('.js-todo-list').innerHTML = todoListHTML;

  // Ajout d’un écouteur d’événement à chaque bouton "Delete"
  document.querySelectorAll('.js-delete-todo-button').forEach((deleteButton) => {
    deleteButton.addEventListener('click', (event) => {
      const index = event.target.dataset.index;
      todoList.splice(index, 1); // Supprime la tâche correspondante
      renderTodoList(); // Réaffiche la liste mise à jour
    });
  });
}

document.querySelector('.js-add-todo-button')
  .addEventListener('click', () => {
    addTodo();
  });

function addTodo() {
  const inputElement = document.querySelector('.js-name-input');
  const name = inputElement.value.trim();

  const dateInputElement = document.querySelector('.js-due-date-input');
  const dueDate = dateInputElement.value;

  // Vérifie que le champ n’est pas vide
  if (name === '' || dueDate === '') {
    alert('Veuillez remplir le nom et la date.');
    return;
  }

  // Ajoute la nouvelle tâche au tableau
  todoList.push({
    name: name,
    dueDate: dueDate
  });

  // Vide les champs
  inputElement.value = '';
  dateInputElement.value = '';

  renderTodoList();
}
